let handler = async m => m.reply(`

╭⭑⭑⭑★✪ *XLICON* ✪★⭑⭑⭑
│ 📂 *BOT Name:* _XLICON-V2-MD_
│ 📝 *Description:* _I'm XLICON-V2. A MultiDevice WhatsApp bot with rich features Created By SALMAN AMAD and Abraham Dwamena._
│ 👤 *Owner:* _Salman Ahmad_
│ 🌐 *Channel:* https://whatsapp.com/channel/0029VaE8GbCDzgTILE7OtC3e
╰━━━━━━━━━━━━━━━━╯
`.trim())
handler.help = ['channel']
handler.tags = ['main']
handler.command = ['xchannel', 'channel' ] 

export default handler
