let handler = async m => m.reply(`




⎯꯭̽ *GROUPS*⎯꯭̽.
─━━━✧✿✧━━━─

Group1:
_____________________
https://chat.whatsapp.com/C4ivwZKuh5bLJkqfYNPQsk
_______________________

Group2:
_______________________
https://chat.whatsapp.com/BfH0KLkICn2BjmGFMRcGMW
_________________________

*DEVELOPERS*/
1:___________________🔰 *MOD'S* 🔰_
wa.me/923184070915
𝙎𝘼𝙇𝙈𝘼𝙉 𝘼𝙃𝙈𝘼𝘿 -𝘼𝙝𝙢𝙢𝙞

2:__________________🔰 *MOD'S* 🔰_
wa.me/233533763772
*ABRAHAM DWAMENA*
_______________________
𝐋ᶦᵏᵉ  𝐂ᵒᵐᵐᵉⁿᵗ   𝐒ᵃᵛᵉ   𝐒ʰᵃʳᵉ
💫   🍷   🎊   🍁   🌙   🪄 
┊    ┊    ┊    ┊    ┊    ┊
┊    ┊    ┊    ┊    ┊   🤍
┊    ┊    ┊    ┊    💜                          
┊    ┊    ┊   💙
┊    ┊   💚   
┊   💛
❤️
*_▬▭▬▭▬▭▬▭▬▭_*
*╰─ ➤XLICON V2*                    
                     ☟︎︎︎
 *̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊╰─☞︎︎︎TEAM XLICON
Salman amand & Abraham Dwamena
 ♥️     ✍🏻ㅤ   📩     📤 
 *_ˡᶦᵏᵉ  ᶜᵒᵐᵐᵉⁿᵗ   ˢᵃᵛᵉ    ˢʰᵃʳᵉ_*
`.trim())
handler.help = ['gpguru']
handler.tags = ['main']
handler.command = ['groups', 'groupguru', 'gugp', 'ggp', 'gpguru'] 

export default handler
