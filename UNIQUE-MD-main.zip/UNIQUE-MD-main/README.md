<p align="center">  
  <a href="https://youtu.be/@wasitech1">
    <img alt="Guru" height="300" src="https://i.imgur.com/CCr6l9P.jpeg">
    <h1 align="center">UNIQUE-MD 2.O</h1>
  </a>
</p>
<p align="center">
<a href="https://github.com/Itxxwasi"><img title="Author" src="https://img.shields.io/badge/UNIQUE-MD-black?style=for-the-badge&logo=telegram"></a>
<p/>
<p align="center">
<a href="https://github.com/Itxxwasi?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/Itxxwasi?label=Followers&style=social"></a>
<a href="https://github.com/Itxxwasi/UNIQUE-MD/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Itxxwasi/UNIQUE-MD?&style=social"></a>
<a href="https://github.com/Itxxwasi/UNIQUE-MD/network/members"><img title="Fork" src="https://img.shields.io/github/forks/Itxxwasi/UNIQUE-MD?style=social"></a>
<a href="https://github.com/Itxxwasi/UNIQUE-MD/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Itxxwasi/UNIQUE-MD?label=Watching&style=social"></a>
<a href="https://app.fossa.com/projects/git%2Bgithub.com%2FItxxwasi%2FUNIQUE-MD?ref=badge_shield" alt="FOSSA Status"><img src="https://app.fossa.com/api/projects/git%2Bgithub.com%2FItxxwasi%2FUNIQUE-MD.svg?type=shield"/></a>
</p>

 
<h1 align="center">📍𝗪𝗔𝗦𝗜 𝗧𝗘𝗖𝗛📍</h1>

#### 🪩 To Change the owner number click here [Config](https://github.com/Itxxwasi/unique-md/blob/main/config.js#L8)🪩

#### SETUP

1. Fork the repo
    <br>
<a href='https://github.com/Itxxwasi/UNIQUE-MD/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork Repo-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>



2. Get Session ID (Server 1)
   > For Indian users Connect to a usa Vpn while login
    
     <a href='https://pair-qr-wasi-md.onrender.com' target="_blank"><img alt='SESSION ID' src='https://img.shields.io/badge/Session_id-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>


3. Get Session ID (Server 2) (use this if server 1 Doesn't work)
    <br>
<a href='https://pair-qr-wasi-md.onrender.com' target="_blank"><img alt='SESSION ID' src='https://img.shields.io/badge/Session_id-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>


#### 𝕕𝕖𝕡𝕝𝕠𝕪𝕞𝕖𝕟𝕥 𝕤𝕖𝕔𝕥𝕚𝕠𝕟
# <a href="https://dashboard.heroku.com/new?template=https://github.com/Itxxwasi/UNIQUE-MD"><img title="heroku" src="https://img.shields.io/badge/DEPLOY ON HEROKU-h?color=green&style=for-the-badge&logo=msi"></a>
# <a href="https://railway.app/template/tM2McB?referralCode=v7Xehd"><img title="railway" src="https://img.shields.io/badge/DEPLOY ON RAILWAY-h?color=green&style=for-the-badge&logo=msi"></a>
# <a href="(https://replit.com/github/Itxxwasi/UNIQUE-MD"><img title="raplir" src="https://img.shields.io/badge/RAPLIT-h?color=green&style=for-the-badge&logo=msi"></a>
# <a href="https://wasimd-9dedcea2edba.herokuapp.com/"><img title="koyeb" src="https://img.shields.io/badge/DEPLOY ON KYOEB-h?color=green&style=for-the-badge&logo=msi"></a>

---------

###  <a href="https://github.com/Itxxwasi"><img src="https://github.com/Itxxwasi.png" width="250" height="250" alt="Itxx Me Wasi"/></a>
### [FOLLOW WASI SER ON GITHUB](https://github.com/Itxxwasi)
### EXTRA SET-UP
### If you don't have mangodb you can use these public dB's
#### MONGODB ARE NOT  REQUIRED 


```
mongodb+srv://wasimd:wasi@cluster0.nqlpjdu.mongodb.net/?retryWrites=true&w=majority
```
```
mongodb+srv://Maher:Zubair@sigma-male.ggwx4gc.mongodb.net/?retryWrites=true&w=majority`

```
```

mongodb+srv://xIKRATOSx:xIKRATOSx@ikratosofc.g1ueru5.mongodb.net/?retryWrites=true&w=majority

```

###  [SUBCRIBE MY YOUTUBE CHANNLE](https://youtube.com/@wasitech1)



