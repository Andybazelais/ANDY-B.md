let handler = async m => m.reply(`
★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆
≡★☆WASI SER INFO☆★≡

★𝚂𝚄𝙿𝙿𝙾®𝚃 𝙶𝚁𝙾𝚄𝙿 𝙻𝙸𝙽𝙺★
─────────────
▢ ★☆☆🛡️CHANNLE🛡️☆☆★

Follow the 𝗪𝗔𝗦𝗜___𝗧𝗘𝗖𝗛 channel on WhatsApp: https://whatsapp.com/channel/0029VaDK8ZUDjiOhwFS1cP2j

★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★
★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆
 
★   ☆   ★   ☆   ★   ☆   ★   ☆
┊   ┊　　┊　　┊　　┊
┊   ┊　　┊　　┊　　★
┊   ┊　　┊　　☆
┊   ┊　　★
┊   ☆
★${developer}★
★☆WASI MD☆★
★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★☆★
`.trim())
handler.help = ['info']
handler.tags = ['main']
handler.command = ['groups', 'groupprince', 'gugp', 'ggp', 'support'] 

export default handler
